import {type_motive} from "./src/Landing.js"
import {toggle_menu} from "./src/Menu.js"
import {toggle_search} from "./src/ToggleSearch.js"


type_motive()
toggle_menu()
toggle_search()

