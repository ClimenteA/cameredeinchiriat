// Listen on click for all elements with data-route attribute
// Render template/view based on route
// Separate elements with data-route atribute in 2
// forms (because we get formsData) and 
// other (simple get request with or without parameters)

// Simple path : "/home" , "/"
// Path with parameters: "/listing/:city/:price"
// Path with specified parameter type: "/listing/int:id", "/listing/int:id/string:city"


// DEMO

// var routes = document.querySelectorAll("[data-route]")
// undefined
// links
// NodeList(2) [img.logo, a]
// links[1]
// <a data-route=​"/​home" href=​"cont_utilizator.html">​Intra in cont​</a>​
// links[1].pathname
// "/cont_utilizator.html"

// document.forms[0].dataset
// DOMStringMap {route: "/intra-in-cont"}
// document.forms[0].dataset.route
// "/intra-in-cont"

// var routes = document.querySelectorAll("[data-route]")
// undefined
// routes
// NodeList(2) [img.logo, a]
// routes[0]
// <img data-route=​"/​home/​:​id" class=​"logo" src=​"./​static/​logo_white.svg" alt=​"camere de inchiriat">​
// routes[0].dataset
// DOMStringMap {route: "/home/:id"}
// routes[0].dataset.route
// "/home/:id"


